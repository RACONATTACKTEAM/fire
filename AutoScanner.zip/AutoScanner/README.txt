usage: python AutoScanner.py

rest is self explainable, the script will run you through it easily

make sure all of your Lists are in the VPS before running the script


Made by charge.
Discord: charge.#6666
IG: @switchnets
Website: https://theswitcharchive.com